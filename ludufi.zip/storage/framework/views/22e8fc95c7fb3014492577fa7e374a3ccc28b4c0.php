<div class="container">
     <div class="row justify-content-center">
         <div class="col-md-8">
             <div class="card">
                 <div class="card-header"><h1>Alert</h1></div>
                   <div class="card-body">
                    <?php if(session('resent')): ?>
                         <div class="alert alert-success" role="alert">
                            <?php echo e(__('A fresh verification link has been sent to your email address.')); ?>

                        </div>
                    <?php endif; ?>
					<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p><span style="font-weight: bold;"><?php echo e($detail->name); ?></span> has not played any battle on <?= date('Y-m-d', strtotime('-1 day', strtotime(date('Y-m-d')))) ?></p>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\ludufii\resources\views/notification/notify.blade.php ENDPATH**/ ?>