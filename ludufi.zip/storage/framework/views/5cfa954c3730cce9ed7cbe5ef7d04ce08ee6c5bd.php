


<?php $__env->startSection('content'); ?>
<?php
//$axies = $data->data->axies->total;
?>
			<!-- Inner content -->
			<div class="content-inner">

				<!-- Content area -->
				<div class="content">
					<div class="row">
						<div class="col-lg-12">
							<div class="card">
								<div class="card-body">
									<div class="tab-content">				
<!-- Axis tick rotation -->
<div class="row">
	<div class="col-sm-12">
	
	<!-- Basic datatable -->
					<?php $class=$breed=array(); ?>
					<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $axiedata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if(!empty($axiedata['axie']->data->axies->results)): ?>
					<?php $__currentLoopData = $axiedata['axie']->data->axies->results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $axie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php $class[]=$axie->class; 
						  $breed[]=$axie->breedCount; 
					?>	
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php $__currentLoopData = $axiedata['info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php $name[]=$nam->name; 
					?>	
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php $clas=array_unique($class);
						  $bred=array_unique($breed); 
						  $naam=array_unique($name);  ?>
		<div class="card">
			<div class="card-header text-right">
			<div class="row">
			<div class="col-sm-2 text-center">
				<label>Search by Class</label>
				<select id="searchClass" class="form-control">
				<option value="">All</option>
					<?php $__currentLoopData = $clas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cls): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($cls); ?>"><?php echo e($cls); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</div>
			<div class="col-sm-2 text-center">
				<label>Search by Owner</label>
				<select id="searchOwner" class="form-control">
				<option value="">All</option>
					<?php $__currentLoopData = $naam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nama): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($nama); ?>"><?php echo e($nama); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</div>
			<div class="col-sm-2 text-center">
				<label>Search by Breed</label>
				<select id="searchBreed" class="form-control">
				<option value="">All</option>
					<?php $__currentLoopData = $bred; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($brd); ?>"><?php echo e($brd); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</div>
			</div></div>
			
			<table id="example" class="table datatable-basic">
				<thead style="background: #99999f;color: white;">
					<tr>
						<th></th>
						<th>Name</th>
						<th>Owner</th>
						<th>Class</th>
						<th>Stats</th>
						<th>Purity</th>
						<th>Breed</th>
						<th>Find Similar Axie</th>
					</tr>
				</thead>
				<tbody>
				<?php if(!empty($data)): ?>
					<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $axiedata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if(!empty($axiedata['axie']->data->axies->results)): ?>
					<?php $__currentLoopData = $axiedata['axie']->data->axies->results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $axie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr data-child-value='<div style="background-color:rgb(250 249 250)" class="row">
					<div style="background-color:rgb(250 249 250)" class="col-sm-6">
					<div style="background-color:rgb(250 249 250)" class="card">
					<h4 style="background-color:rgb(250 249 250);margin: 2%;">Body Parts</h4>
					<div class="row text-center" style="margin: 2%;">
					<?php $__currentLoopData = $axie->parts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="col-sm-4">
						<i style="color: #01b49a;" <?php if($parts->type=="Eyes"): ?> class="fas fa-eye mr-3 fa-2x" <?php elseif($parts->type=="Ears"): ?> class="mi-hearing" <?php elseif($parts->type=="Back"): ?> class="fab fa-wolf-pack-battalion mr-3 fa-2x" <?php elseif($parts->type=="Mouth"): ?> class="fas fa-teeth-open mr-3 fa-2x" <?php elseif($parts->type=="Horn"): ?> class="fab fa-hornbill mr-3 fa-2x" <?php elseif($parts->type=="Tail"): ?> class="fas fa-kiwi-bird mr-3 fa-2x" <?php endif; ?> ></i><br><span style="font-size: large;font-weight: bolder;"><?php echo e($parts->name); ?></span>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div></div>
					</div>
					<div style="background-color:rgb(250 249 250)" class="col-sm-6">
					<div style="background-color:rgb(250 249 250)" class="card">
					<h4 style="background-color:rgb(250 249 250);margin: 2%;">GENETIC</h4>
					<div class="row text-center">
					<div class="col-sm-4">
					<label class="col-lg-12">D</label>
					<?php $__currentLoopData = $axie->parts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<label style="color: #01b49a;" class="col-lg-12">
					<?php echo e($parts->name); ?>

					</label>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div></div></div></div>
					</div>'>
						<td class="details-control"><i style="color: blue;" class="icon-arrow-resize8 mr-3 icon-2x"></i></td>
						<td style="font-weight: bold;" class="dt-control">
						<img src="<?php echo e($axie->image); ?>" width="75px" alt="new">
							<?php echo e($axie->name); ?><br><?php echo e($axie->id); ?>

						</td>
						<td style="font-weight: bold;">
							<?php echo e($axiedata['info'][0]->name); ?><br><span style="font-weight: initial;font-size:11px"><?php echo e(Str::limit($axiedata['info'][0]->ronin_address,15, $end='....')); ?></span>
						</td>
						<td style="font-weight: bold;width:9%">
						<input type="hidden" id="inputClass" value="<?php echo e($axie->class); ?>">
						<i 
							<?php if($axie->class=='Plant'): ?>
							style="color: rgb(108 192 0);font-size: inherit;" class='fas fa-leaf mr-3 fa-2x'
							<?php elseif($axie->class=='Bug'): ?>
							style="color: rgb(255 83 65);font-size: x-large;" class='mi-bug-report'
							<?php elseif($axie->class=='Aquatic'): ?>
							style="color: rgb(0 184 206);font-size: inherit;" class='fas fa-fish mr-3 fa-2x'
							<?php endif; ?>
							></i>
							<?php echo e($axie->class); ?>

						</td>
						<td style="font-weight: bold;width:15%">
							<i style="color: rgb(58 194 121)" class='icon-heart5'></i><?php echo e($axie->stats->hp); ?>

							<i style="color: rgb(106 58 194)" class='icon-star-full2'></i><?php echo e($axie->stats->speed); ?>

							<i style="color: rgb(247 172 10)" class='icon-power3'></i><?php echo e($axie->stats->skill); ?>

							<i style="color: rgb(194 58 58)" class='icon-fire'></i><?php echo e($axie->stats->morale); ?>

						</td>
						<td style="font-weight: bold;">
							Purity
						</td>
						<td style="font-weight: bold;">
							<?php echo e($axie->breedCount); ?>

						</td>
						<td style="font-weight: bold;">
							<?php echo e($axie->breedCount); ?>

						</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>
				</tbody>
			</table>
		</div>
	<!-- /basic datatable -->
	</div>
</div>
<!-- /axis tick rotation -->

						</div>
					</div>
					
<script>
function format(value) {
      return value;
  }
  $.fn.dataTable.ext.search.push(
    function( settings, data, dataIndex ) {
        var searchClass =  $('#searchClass').val();
        var searchBreed =  $('#searchBreed').val();
        var searchOwner =  $('#searchOwner').val();
		var clas= data[3].trim();
		var bred= data[6].trim();
		var spl= data[2].trim().split('ronin');
		var name= spl[0]
		console.log(name);
        if ( (searchClass=='' && searchBreed=='' && searchOwner=='') || 
		( searchClass!='' && searchClass == clas && searchBreed=='' && searchOwner=='' ) ||
		( searchBreed!='' && searchBreed == bred && searchClass=='' && searchOwner=='' ) ||
		( searchOwner!='' && searchOwner == name && searchClass=='' && searchBreed=='' ) ||
		( searchBreed!='' && searchClass!='' && searchBreed == bred && searchClass == clas && searchOwner == '' ) ||
		( searchOwner!='' && searchClass!='' && searchOwner == name && searchClass == clas && searchBreed == '' ) ||
		( searchBreed!='' && searchOwner!='' && searchBreed == bred && searchOwner == name && searchClass == '' ) ||
		( searchBreed!='' && searchClass!='' && searchOwner!='' && searchBreed == bred && searchClass == clas && searchOwner == name )
		) 
        {
            return true;
        }
        return false;
    }
);
  $(document).ready(function () {
      var table = $('#example').DataTable({});
	  
    // Event listener to the two range filtering inputs to redraw on input
    $('#searchClass,#searchBreed,#searchOwner').change( function() {
        table.draw();
    } );

      // Add event listener for opening and closing details
      $('#example').on('click', 'td.details-control', function () {
          var tr = $(this).closest('tr');
          var row = table.row(tr);

          if (row.child.isShown()) {
              // This row is already open - close it
              row.child.hide();
              tr.removeClass('shown');
          } else {
              // Open this row
              row.child(format(tr.data('child-value'))).show();
              tr.addClass('shown');
          }
      });
  });

</script>
				<!-- Footer -->
				<div class="navbar navbar-expand-lg navbar-light border-bottom-0 border-top">
					<div class="text-center d-lg-none w-100">
						<button type="button" class="navbar-toggler dropdown-toggle" data-toggle="collapse" data-target="#navbar-footer">
							<i class="icon-unfold mr-2"></i>
							Footer
						</button>
					</div>

					<div class="navbar-collapse collapse" id="navbar-footer">
						<span class="navbar-text">
							&copy; 2022. <a href="#">Ludufy-Web Portal</a>
						</span>

					</div>
				</div>
				
				<!-- /footer -->

			</div>
			<!-- /inner content -->
			</div>

		
<?php $__env->stopSection(); ?>
<?php echo $__env->make('auth.includes.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ludufii\resources\views/axies.blade.php ENDPATH**/ ?>