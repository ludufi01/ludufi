<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use DB;
use App\Models\ScholarTracker;
use Illuminate\Routing\Controller as BaseController;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;
	
	public function curlRes($url,$type,$ronin,$postData)
    {
		$curl = curl_init();
		curl_setopt_array($curl, array(
		  CURLOPT_URL => $url,
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => '',
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 0,
		  CURLOPT_FOLLOWLOCATION => true,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => $type,
			  CURLOPT_POSTFIELDS =>$postData,
				CURLOPT_HTTPHEADER => array(
				'Content-Type: application/json'
				),
		));
		$response = curl_exec($curl);
		curl_close($curl);
		return $response;
    }
	
	public function getAxieDetails($ronin,$managerPer,$name)
	{
		$finalData=array();
		$url = 'https://game-api.axie.technology/slp/'.$ronin;
		$slp = $this->curlRes($url,'GET','','');
		$url = 'https://game-api.axie.technology/mmr/'.$ronin;
		$mmr = $this->curlRes($url,'GET','','');
		$url = 'https://game-api.axie.technology/api/v1/'.$ronin;
		$v1 = $this->curlRes($url,'GET','','');
		$url = 'https://graphql-gateway.axieinfinity.com/graphql';
		$postData='{
			"operationName": "GetAxieBriefList",
			"variables": {
			"owner":"'.$ronin.'",
			"criteria": {}
			},
			"query": "query GetAxieBriefList($auctionType: AuctionType, $criteria: AxieSearchCriteria, $from: Int, $sort: SortBy, $size: Int, $owner: String) {\\n  axies(auctionType: $auctionType, criteria: $criteria, from: $from, sort: $sort, size: $size, owner: $owner) {\\n    total\\n    results {\\n      ...AxieBrief\\n      __typename\\n    }\\n    __typename\\n  }\\n}\\n\\nfragment AxieBrief on Axie {\\n  id\\n  name\\n  stage\\n  class\\n  breedCount\\n  image\\n  title\\n  battleInfo {\\n    banned\\n    __typename\\n  }\\n  auction {\\n    currentPrice\\n    currentPriceUSD\\n    __typename\\n  }\\n  parts {\\n    id\\n    name\\n    class\\n    type\\n    specialGenes\\n    __typename\\n  }\\n  __typename\\n}\\n"
			}';
		$axie = $this->curlRes($url,'POST',$ronin,$postData);
		
		$mmr=json_decode($mmr);
		$slp=json_decode($slp);
		$v1=json_decode($v1);
		$axie=json_decode($axie);
		
		$finalData['ronin']=$ronin;
			$roninID=explode('x',$mmr[0]->items[1]->client_id);
			$roninAdd='ronin:'.$roninID[1];
		$finalData['name']=$name;
		$finalData['roninAdd']=$roninAdd;
		$finalData['winTotal']=$mmr[0]->items[1]->win_total;
		$finalData['drawTotal']=$mmr[0]->items[1]->draw_total;
		$finalData['loseTotal']=$mmr[0]->items[1]->lose_total;
		$finalData['elo']=$mmr[0]->items[1]->elo;
		$finalData['rank']=$mmr[0]->items[1]->rank;
		
		$finalData['axietotal']=$axie->data->axies->total;;
		
		$finalData['total']=$slp[0]->total;
		$finalData['claimableTotal']=$slp[0]->claimable_total;
		$seconds = $slp[0]->last_claimed_item_at / 1000;
		$last_claimed_item_at=date("d-m-Y", $seconds);
		$finalData['lastClaimedItemAt']=$last_claimed_item_at;
		$finalData['rawTotal']=$slp[0]->raw_total;
		$finalData['rawClaimableTotal']=$slp[0]->raw_claimable_total;
		$scholarPer=100-$managerPer;
		$finalData['manager']=round(($slp[0]->total*$managerPer)/100);
		$finalData['scholar']=$finalData['total']-$finalData['manager'];
		
		return $finalData;
	}
	
	public function getMultiAxieDetails($ronin)
	{
		$axie=array();
		$finalData=array();
		$url = 'https://game-api.axie.technology/slp/'.$ronin;
		$slp = $this->curlRes($url,'GET','','');
		$url = 'https://game-api.axie.technology/mmr/'.$ronin;
		$mmr = $this->curlRes($url,'GET','','');
		$url = 'https://game-api.axie.technology/api/v1/'.$ronin;
		$v1 = $this->curlRes($url,'GET','','');
		$roninAfter=explode(',',$ronin);
		foreach($roninAfter as $roninSingle)	{
			if(!empty($roninSingle)) {
		$url = 'https://graphql-gateway.axieinfinity.com/graphql';
		$postData='{
			"operationName": "GetAxieBriefList",
			"variables": {
			"owner":"'.$roninSingle.'",
			"criteria": {}
			},
			"query": "query GetAxieBriefList($auctionType: AuctionType, $criteria: AxieSearchCriteria, $from: Int, $sort: SortBy, $size: Int, $owner: String) {\\n  axies(auctionType: $auctionType, criteria: $criteria, from: $from, sort: $sort, size: $size, owner: $owner) {\\n    total\\n    results {\\n      ...AxieBrief\\n      __typename\\n    }\\n    __typename\\n  }\\n}\\n\\nfragment AxieBrief on Axie {\\n  id\\n  name\\n  stage\\n  class\\n  breedCount\\n  image\\n  title\\n  battleInfo {\\n    banned\\n    __typename\\n  }\\n  auction {\\n    currentPrice\\n    currentPriceUSD\\n    __typename\\n  }\\n  parts {\\n    id\\n    name\\n    class\\n    type\\n    specialGenes\\n    __typename\\n  }\\n  __typename\\n}\\n"
			}';
		$axie[] = json_decode($this->curlRes($url,'POST',$roninSingle,$postData));
		}	}
		$mmr=json_decode($mmr);
		$slp=json_decode($slp);
		$v1=json_decode($v1);
		$sr=0;
		foreach($mmr as $mmrSingle) {
		if(!empty($mmrSingle))	{
		if(isset($mmrSingle->items[1]))	{
			$roninID=explode('x',$mmrSingle->items[1]->client_id);
			$roninAdd='ronin:'.$roninID[1];
			
		$info = ScholarTracker::getInformation($roninAdd);
		$finalData[$sr]['ronin']=$mmrSingle->items[1]->client_id;
		$finalData[$sr]['roninAdd']=$roninAdd;
		$finalData[$sr]['name']=$info[0]->name;
		$finalData[$sr]['winTotal']=$mmrSingle->items[1]->win_total;
		$finalData[$sr]['drawTotal']=$mmrSingle->items[1]->draw_total;
		$finalData[$sr]['loseTotal']=$mmrSingle->items[1]->lose_total;
		$finalData[$sr]['elo']=$mmrSingle->items[1]->elo;
		$finalData[$sr]['rank']=$mmrSingle->items[1]->rank;
		$sr++;
		}	}	}
		$sr=0;
		foreach($axie as $axieSingle) {
		if(!empty($axieSingle))	{
		if(isset($axieSingle->data->axies->total))	{
		$finalData[$sr]['axietotal']=$axieSingle->data->axies->total;
		$sr++;
		}	}	}
		$sr=0;
		foreach($slp as $slpSingle) {
		if(!empty($slpSingle))	{
		if(isset($slpSingle->total))	{
		$finalData[$sr]['total']=$slpSingle->total;
		$finalData[$sr]['claimableTotal']=$slpSingle->claimable_total;
		$seconds = $slpSingle->last_claimed_item_at / 1000;
		$last_claimed_item_at=date("d-m-Y", $seconds);
		$finalData[$sr]['lastClaimedItemAt']=$last_claimed_item_at;
		$finalData[$sr]['rawTotal']=$slpSingle->raw_total;
		$finalData[$sr]['rawClaimableTotal']=$slpSingle->raw_claimable_total;
		
		$roninID=explode('x',$slpSingle->client_id);
		$roninAdd='ronin:'.$roninID[1];
		$info = ScholarTracker::getInformation($roninAdd);
		$scholarPer=100-$info[0]->manager_percentage;
		$finalData[$sr]['manager']=round(($slpSingle->total*$info[0]->manager_percentage)/100);
		$finalData[$sr]['scholar']=$slpSingle->total-round(($slpSingle->total*$info[0]->manager_percentage)/100);
		$sr++;
		}	}	}
		return $finalData;
	}

	public function getMultiAxies($ronins)
	{
		$finalData=array();
		
		$sr=0;
		$roninAfter=explode(',',$ronins);
		foreach($roninAfter as $roninSingle)	{
			if(!empty($roninSingle)) {
		$url = 'https://graphql-gateway.axieinfinity.com/graphql';
		$postData='{
		"operationName": "GetAxieBriefList",
		"variables": {
		"from": 0,
		"size": 100,
		"sort": "IdDesc",
		"auctionType": "All",
		"owner":"'.$roninSingle.'",
		"criteria": {
		"region": null,
		"parts": null,
		"bodyShapes": null,
		"classes": null,
		"stages": null,
		"numMystic": null,
		"pureness": null,
		"title": null,
		"breedable": null,
		"breedCount": null,
		"hp": [],
		"skill": [],
		"speed": [],
		"morale": []
		}
		},
		"query": "query GetAxieBriefList(\n        $auctionType: AuctionType,\n        $criteria: AxieSearchCriteria,\n        $from: Int,\n        $sort: SortBy,\n        $size: Int,\n        $owner: String\n      ) {\n  \n      axies(\n        auctionType: $auctionType,\n        criteria: $criteria,\n        from: $from,\n        sort: $sort,\n        size: $size,\n        owner: $owner\n      ) {\n        \n    total\n        \n    results \n        {\n      ...AxieBrief\n      __typename\n    }\n\n        __typename\n  \n      }\n      \n}\n      \n\n \n      \n      fragment AxieStats on AxieStats {\n        hp\n        speed\n        skill\n        morale\n        __typename\n      }\n      \n      fragment AxieBrief on Axie {\n        \n  id\n        \n  name\n        \n  stage\n        \n  class\n        \n birthDate\n        \n breedCount\n        \n stats {\n        \n  ...AxieStats\n        \n  __typename\n        \n }\n        \n image\n        \n  genes\n        \n  battleInfo {\n    banned\n    __typename\n  }\n        \n  parts {\n          \n    id\n          \n    name\n          \n    class\n          \n    type\n          \n    specialGenes\n          \n    __typename\n        \n  }\n        \n  __typename\n        \n}\n      \n"
		}';
		$finalData[$sr]['axie'] = json_decode($this->curlRes($url,'POST',$roninSingle,$postData));
		$roninSin=explode('x',$roninSingle);
		$ronin='ronin:'.$roninSin[1];
		
		$finalData[$sr]['info'] = ScholarTracker::getInformation($ronin); 
		$sr++;
		}	}
		return $finalData;
	}

	public function getSingleAxieDetail($ronin,$managerPer,$name)
	{
		$finalData=array();
		$url = 'https://game-api.axie.technology/slp/'.$ronin;
		$slp = $this->curlRes($url,'GET','','');
		$url = 'https://game-api.axie.technology/mmr/'.$ronin;
		$mmr = $this->curlRes($url,'GET','','');
		$url = 'https://game-api.axie.technology/logs/pvp/'.$ronin;
		$battles1 = $this->curlRes($url,'GET','','');
		$url = 'https://game-api.axie.technology/logs/pve/'.$ronin;
		//$battles2 = $this->curlRes($url,'GET','','');
		$url = 'https://game-api.axie.technology/api/v1/'.$ronin;
		$v1 = $this->curlRes($url,'GET','','');
		$url = 'https://graphql-gateway.axieinfinity.com/graphql';
		$postData='{
		"operationName": "GetAxieBriefList",
		"variables": {
		"from": 0,
		"size": 100,
		"sort": "IdDesc",
		"auctionType": "All",
		"owner": "'.$ronin.'",
		"criteria": {
		"region": null,
		"parts": null,
		"bodyShapes": null,
		"classes": null,
		"stages": null,
		"numMystic": null,
		"pureness": null,
		"title": null,
		"breedable": null,
		"breedCount": null,
		"hp": [],
		"skill": [],
		"speed": [],
		"morale": []
		}
		},
		"query": "query GetAxieBriefList(\n        $auctionType: AuctionType,\n        $criteria: AxieSearchCriteria,\n        $from: Int,\n        $sort: SortBy,\n        $size: Int,\n        $owner: String\n      ) {\n  \n      axies(\n        auctionType: $auctionType,\n        criteria: $criteria,\n        from: $from,\n        sort: $sort,\n        size: $size,\n        owner: $owner\n      ) {\n        \n    total\n        \n    results \n        {\n      ...AxieBrief\n      __typename\n    }\n\n        __typename\n  \n      }\n      \n}\n      \n\n \n      \n      fragment AxieStats on AxieStats {\n        hp\n        speed\n        skill\n        morale\n        __typename\n      }\n      \n      fragment AxieBrief on Axie {\n        \n  id\n        \n  name\n        \n  stage\n        \n  class\n        \n birthDate\n        \n breedCount\n        \n stats {\n        \n  ...AxieStats\n        \n  __typename\n        \n }\n        \n image\n        \n  genes\n        \n  battleInfo {\n    banned\n    __typename\n  }\n        \n  parts {\n          \n    id\n          \n    name\n          \n    class\n          \n    type\n          \n    specialGenes\n          \n    __typename\n        \n  }\n        \n  __typename\n        \n}\n      \n"
		}';
		$axie = $this->curlRes($url,'POST',$ronin,$postData);
		
		$mmr=json_decode($mmr);
		$slp=json_decode($slp);
		$v1=json_decode($v1);
		
		$finalData['ronin']=$ronin;
		$finalData['name']=$name;
		$finalData['winTotal']=$mmr[0]->items[1]->win_total;
		$finalData['drawTotal']=$mmr[0]->items[1]->draw_total;
		$finalData['loseTotal']=$mmr[0]->items[1]->lose_total;
		$finalData['elo']=$mmr[0]->items[1]->elo;
		$finalData['rank']=$mmr[0]->items[1]->rank;
		
		$finalData['axietotal']=json_decode($axie);
		$finalData['battles1']=json_decode($battles1);
		
		$finalData['total']=$slp[0]->total;
		$finalData['claimableTotal']=$slp[0]->claimable_total;
		$seconds = $slp[0]->last_claimed_item_at / 1000;
		$last_claimed_item_at=date("d-m-Y", $seconds);
		$finalData['lastClaimedItemAt']=$last_claimed_item_at;
		$finalData['rawTotal']=$slp[0]->raw_total;
		$finalData['rawClaimableTotal']=$slp[0]->raw_claimable_total;
		$scholarPer=100-$managerPer;
		$finalData['manager']=round(($slp[0]->total*$managerPer)/100);
		$finalData['scholar']=$finalData['total']-$finalData['manager'];
		
		return $finalData;
	}
	
}

