<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use DB;
use App\Models\ScholarTracker;
use Auth;

class HomeController extends Controller
{
    public function home()
    {
		if(!Auth::user())
		{
		  return redirect('login');
		}	else {
		$finalData=array();
		$scholar=ScholarTracker::get();
		$roninAdd='';
		foreach($scholar as $scholars)
		{
			$ronin=explode(':',$scholars->ronin_address);
			$roninAdd=$roninAdd.'0x'.$ronin[1].',';
		}
			$finalData=$this->getMultiAxieDetails($roninAdd);
		  return view('dashboard', compact('finalData'));
		}
    }
	
    public function overview()
    {
		if(!Auth::user())
		{
		  return redirect('login');
		}	else {
		$finalData=array();
		$scholar=ScholarTracker::get();
		$roninAdd='';
		foreach($scholar as $scholars)
		{
			$ronin=explode(':',$scholars->ronin_address);
			$roninAdd=$roninAdd.'0x'.$ronin[1].',';
		}
			$finalData=$this->getMultiAxieDetails($roninAdd);
		  return view('overview', compact('finalData'));
		}
    }
	
    public function addTracker(Request $request)
    {
		if(!Auth::user())
		{
		  return redirect('login');
		}	else {
        
          $validator = \Validator::make($request->all(), [
              'ronin_address' => 'required|unique:scholar_trackers'
          ]);
			if ($validator->fails())
			{
			return response()->json(['errors' => $validator->errors()->all()]);
			}
       ScholarTracker::create([
              'name' => $request->name,
              'ronin_address' => $request->ronin_address,
              'manager_percentage' => $request->manager_percentage,
              'scholar_percentage' => $request->scholar_percentage,
              'scholar_ronin_address' => $request->scholar_ronin_address,
              'trainee_percentage' => $request->trainee_percentage,
              'trainee_ronin_address' => $request->trainee_ronin_address	]);
		
		$ronin=explode(':',$request->ronin_address);
		$roninAdd='0x'.$ronin[1];
		
		$data=$this->getAxieDetails($roninAdd,$request->manager_percentage,$request->name);

		return response()->json(['success'=>'Data is successfully added','data'=>$data]);

		}
    }

    public function updateTracker(Request $request)
    {
		if(!Auth::user())
		{
		  return redirect('login');
		}	else {
        
          $validator = \Validator::make($request->all(), [
              'name' => 'required',
              'manager_percentage' => 'required',
          ]);
			if ($validator->fails())
			{
			return response()->json(['errors' => $validator->errors()->all()]);
			}
		$scholar=ScholarTracker::where('id',$request->id)->first();
		
        $scholar->name = $request->name;
        $scholar->manager_percentage = $request->manager_percentage;
        $scholar->scholar_percentage = 100-$request->manager_percentage;
        $scholar->scholar_ronin_address = $request->scholar_ronin_address;
        $scholar->trainee_percentage = $request->trainee_percentage;
        $scholar->trainee_ronin_address = $request->trainee_ronin_address;
        $scholar->save();				

		return response()->json(['success'=>'Data is successfully added','data'=>$scholar]);

		}
    }

    public function editTracker(Request $request)
    {
		if(!Auth::user())
		{
		  return redirect('login');
		}	else {
			$roninID=explode('x',$request->id);
			$roninAdd='ronin:'.$roninID[1];
			$scholar=ScholarTracker::where('ronin_address',$roninAdd)->first();
			return $scholar;
		}
    }

    public function search($roninId)
    {
		if(!Auth::user())
		{
		  return redirect('login');
		}	else {
			
			$scholar=ScholarTracker::where('ronin_address',$roninId)->first();
			$ronin=explode(':',$roninId);
			$roninAdd='0x'.$ronin[1];
			$data=$this->getSingleAxieDetail($roninAdd,$scholar->manager_percentage,$scholar->name);
			
		  return view('search',compact('roninId','data'));
		}
    }
	
    public function axies()
    {
		if(!Auth::user())
		{
		  return redirect('login');
		}	else {
			
			$scholar=ScholarTracker::get();
			$roninAdd='';
			foreach($scholar as $scholars)
			{
				$ronin=explode(':',$scholars->ronin_address);
				$roninAdd=$roninAdd.'0x'.$ronin[1].',';
			}
			$data=$this->getMultiAxies($roninAdd);
			//dd($data);
			
		  return view('axies',compact('data'));
		}
    }
	
}
