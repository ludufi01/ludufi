<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Traits\UploadImageTrait;
use DB;
use App\Models\User;
use App\Models\Quiz;
use Auth;

class QuizController extends Controller
{
    use UploadImageTrait;
	
    public function quiz()
    {
		if(!Auth::user())
		{
		  return redirect('login');
		}	else {
			
		  return view('quiz');
		}
    }
	
    public function store(Request $request) 
	{
        
          $request->validate([
              'full_name' => 'required|string|max:255',
              'email' => 'required|string|email|max:255',
              'twitter_username' => 'required|string|max:255',
              'discord_id' => 'required',
              'previous_mmr' => 'required|string|max:255',
              'ronin_payout_address' => 'required|string|max:255',
              'time_available_axie' => 'required|string|max:255',
              'current_occupation' => 'required|string|max:255',
              'still_student' => 'required|string|max:255',
              'bonus_damage_combo_attack' => 'required|string|max:255',
              'axie_highest_morale' => 'required|string|max:255',
              'axie_skills_additional_damage' => 'required|string|max:255',
              'axie_highest_speed' => 'required|string|max:255',
              'attack_ignore_shield' => 'required|string|max:255',
              'axie_healing_ability' => 'required|string|max:255',
              'axie_melee_cards' => 'required|string|max:255',
              'axie_discard_cards' => 'required|string|max:255',
              'axie_lowest_shield' => 'required|string|max:255',
              'cancel_backdoor_combos' => 'required|string|max:255',
          ]);
		  
        if ($request->hasFile('axie_pul_middle_lane')) {
           $image = $this->uploadImage($request->axie_pul_middle_lane,'quiz');
            if($image['status'] == 200)
            {
                $imagePath = $image['path'];
            }else{
                return redirect()->back()->with('error', 'Invalid image! Please try again')->withInput();
            }
        }	else {
                $imagePath = '';
		}
		  
          Quiz::create([
              'full_name' => $request->full_name,
              'email' => $request->email,
              'twitter_username' => $request->twitter_username,
              'discord_id' => $request->discord_id,
              'previous_mmr' => $request->previous_mmr,
              'ronin_payout_address' => $request->ronin_payout_address,
              'time_available_axie' => $request->time_available_axie,
              'current_occupation' => $request->current_occupation,
              'still_student' => $request->still_student,
              'bonus_damage_combo_attack' => $request->bonus_damage_combo_attack,
              'axie_highest_morale' => $request->axie_highest_morale,
              'axie_skills_additional_damage' => $request->axie_skills_additional_damage,
              'axie_highest_speed' => $request->axie_highest_speed,
              'attack_ignore_shield' => $request->attack_ignore_shield,
              'all_buffs' => json_encode($request->all_buffs),
              'axie_healing_ability' => $request->axie_healing_ability,
              'axie_melee_cards' => $request->axie_melee_cards,
              'axie_discard_cards' => $request->axie_discard_cards,
              'axie_lowest_shield' => $request->axie_lowest_shield,
              'cancel_backdoor_combos' => $request->cancel_backdoor_combos,
              'shrimpinator_special' => $request->shrimpinator_special,
              'kind_axie_card_combos' => $request->kind_axie_card_combos,
              'terminator_special' => $request->terminator_special,
              'disablesour_special' => $request->disablesour_special,
              'reptile_axie_special' => $request->reptile_axie_special,
              'triple_bug_signal_cute_bunny_special' => $request->triple_bug_signal_cute_bunny_special,
              'double_anemone_special' => $request->double_anemone_special,
              'aqua_jump_best_move' => $request->aqua_jump_best_move,
              'axie_pul_middle_lane' => $imagePath,
              'chosen_axie_previous' => $request->chosen_axie_previous,
              'status' => 0,
          ]);
		  
      return redirect()->route('quiz')->with('success', 'Quiz submitted');
		  
    }


}
