<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use DB;
use App\Models\ScholarTracker;
use Auth;

class HomeController extends Controller
{
    public function home()
    {
		if(!Auth::user())
		{
		  return redirect('login');
		}	else {
		  return view('dashboard');
		}
    }
	
    public function addTracker(Request $request)
    {
		if(!Auth::user())
		{
		  return redirect('login');
		}	else {
        
       /* ScholarTracker::create([
              'name' => $request->name,
              'ronin_address' => $request->ronin_address,
              'manager_percentage' => $request->manager_percentage,
              'scholar_percentage' => $request->scholar_percentage,
              'scholar_ronin_address' => $request->scholar_ronin_address,
              'trainee_percentage' => $request->trainee_percentage,
              'trainee_ronin_address' => $request->trainee_ronin_address	]); */
		
		$ronin=explode(':',$request->ronin_address);
		$roninAdd='0x'.$ronin[1];
		
		//print_r($this->getAxieSLP($roninAdd));
		//print_r($this->getAxieMMR($roninAdd));
		print_r($this->getAxieV1($roninAdd));
        die();
		return response()->json(['success'=>'Data is successfully added','data'=>json_decode($response)]);
		}
    }
}
