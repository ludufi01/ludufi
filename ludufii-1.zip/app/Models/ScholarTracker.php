<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ScholarTracker extends Model
{
    use HasFactory;
	
	
    protected $fillable = [
        'name',
        'ronin_address',
        'manager_percentage',
        'scholar_percentage',
        'scholar_ronin_address',
        'trainee_percentage',
        'trainee_ronin_address',
    ];
}
