<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Quiz extends Model
{
    use HasFactory;
	
	protected $fillable = [
        'email',
        'full_name',
        'twitter_username',
        'discord_id',
        'previous_mmr',
        'ronin_payout_address',
        'time_available_axie',
        'current_occupation',
        'still_student',
        'bonus_damage_combo_attack',
        'axie_highest_morale',
        'axie_skills_additional_damage',
        'axie_highest_speed',
        'attack_ignore_shield',
        'all_buffs',
        'axie_healing_ability',
        'axie_melee_cards',
        'axie_discard_cards',
        'axie_lowest_shield',
        'cancel_backdoor_combos',
        'shrimpinator_special',
        'kind_axie_card_combos',
        'terminator_special',
        'disablesour_special',
        'reptile_axie_special',
        'triple_bug_signal_cute_bunny_special',
        'double_anemone_special',
        'aqua_jump_best_move',
        'axie_pul_middle_lane',
        'chosen_axie_previous',
        'status',
    ];
	
}
