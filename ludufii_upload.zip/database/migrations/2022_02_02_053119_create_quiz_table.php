<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateQuizTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('quizzes', function (Blueprint $table) {
            $table->id();
            $table->string('email');
            $table->string('full_name');
            $table->string('twitter_username');
            $table->string('discord_id');
            $table->string('previous_mmr');
            $table->string('ronin_payout_address');
            $table->string('time_available_axie');
            $table->longText('current_occupation');
            $table->string('still_student');
            $table->longText('bonus_damage_combo_attack');
            $table->longText('axie_highest_morale');
            $table->longText('axie_skills_additional_damage');
            $table->longText('axie_highest_speed');
            $table->longText('attack_ignore_shield');
            $table->longText('all_buffs')->nullable();
            $table->longText('axie_healing_ability')->nullable();
            $table->longText('axie_melee_cards')->nullable();
            $table->longText('axie_discard_cards')->nullable();
            $table->longText('axie_lowest_shield')->nullable();
            $table->longText('cancel_backdoor_combos')->nullable();
            $table->longText('shrimpinator_special')->nullable();
            $table->longText('kind_axie_card_combos')->nullable();
            $table->longText('terminator_special')->nullable();
            $table->longText('disablesour_special')->nullable();
            $table->longText('reptile_axie_special')->nullable();
            $table->longText('triple_bug_signal_cute_bunny_special')->nullable();
            $table->longText('double_anemone_special')->nullable();
            $table->longText('aqua_jump_best_move')->nullable();
            $table->longText('axie_pul_middle_lane')->nullable();
            $table->longText('chosen_axie_previous')->nullable();
            $table->integer('status');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('quizzes');
    }
}
